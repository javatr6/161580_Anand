function validate(){
	var flag=false;
	var userName=f1.userName.value
	var userPwd=f1.userPwd.value
   if(userName==""||userName=="null"){
	   document.getElementById('usernamemsg').innerHTML="* Please enter username"; 
	   flag=false;
   }else if(userPwd==""||userPwd=="null"){
	   document.getElementById('userpassmsg').innerHTML="* Please enter password";
	   flag=false;

   }else{
	   flag=true;
   }
	return flag;
}